package misc;

public interface Openable
{
	public boolean isOpen();
	public String open();
	public String close();
}
