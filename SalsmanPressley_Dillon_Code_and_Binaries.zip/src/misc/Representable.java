package misc;

public interface Representable
{
	public char getRepresentation();
}
