package misc;

public class Representation
{
	public char ASCII;
	protected boolean modifiable = true;
	
	public Representation(char ASCII)
	{
		this.ASCII = ASCII;
		// TODO Auto-generated constructor stub
	}
	
	public Representation(char ASCII, boolean isModifiable)
	{
		this.ASCII = ASCII;
		this.modifiable = isModifiable;
		// TODO Auto-generated constructor stub
	}
	
	public boolean isModifiable() {
		return modifiable;
	}
	
	public boolean setASCII(char ASCII) {
		if(modifiable)
		{
			this.ASCII = ASCII;
			return true;
		}
		
		return false;
	}
}
