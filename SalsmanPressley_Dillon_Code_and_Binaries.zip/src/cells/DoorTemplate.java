package cells;

import misc.Openable;

//An example of a cell type with greater complexity
public class DoorTemplate extends CellTemplate
{
	
	DoorTemplate(char ASCII, int TEMPLATE_ID) {
		super(ASCII, TEMPLATE_ID);
	}
	
	@Override
	public Cell makeInstance() {
		if(this.DEFAULT_REPRESENTATION.ASCII == ',')
			return new Door(true);
		return new Door(false);
	}
	
	private class Door extends Cell implements Openable {
	private boolean isOpen = false;
	Door(boolean isOpen) {
		this.isOpen = isOpen;
		this.solid = true;
		this.liquid = false;
	}
	
	@Override
	public char getRepresentation() {
		if(this.isOpen())
			return ',';
		return '+';
	}
	
	@Override
	public boolean isWalkable() {
		return this.isOpen();
	}
	
	@Override
	public boolean isOpen()
	{
		return isOpen;
	}

	@Override
	public String open()
	{
		this.isOpen = true;
		return "The door swings open.";
	}

	@Override
	public String close()
	{
		this.isOpen = false;
		return "The door slams shut.";
	}
	}
}
