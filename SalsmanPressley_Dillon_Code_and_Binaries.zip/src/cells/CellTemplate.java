package cells;

import misc.Representation;

public class CellTemplate extends Cell
{
	public final int TEMPLATE_ID;
	
	CellTemplate(char ASCII, int TEMPLATE_ID) {
		this.DEFAULT_REPRESENTATION = new Representation(ASCII, false);
		this.TEMPLATE_ID = TEMPLATE_ID;
	}
	
	public Cell makeInstance() {
		Cell instance = new Cell(this.DEFAULT_REPRESENTATION.ASCII);
		instance.solid = this.solid;
		instance.liquid = this.liquid;
		instance.walkable = this.walkable;
		
		return instance;
	}
}
