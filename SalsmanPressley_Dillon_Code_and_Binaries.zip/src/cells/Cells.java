package cells;

import java.util.HashMap;

public class Cells
{
	private static HashMap<Integer, CellTemplate> cells = new HashMap<Integer, CellTemplate>();
	
	public static final CellTemplate AIR = initAIR();
	public static final CellTemplate GRANITE_WALL = initGRANITE_WALL();
	
	public static final CellTemplate STAIRS_UP = initSTAIRS_UP();
	public static final CellTemplate STAIRS_DOWN = initSTAIRS_DOWN();

	public static final CellTemplate OPEN_DOOR = initOPEN_DOOR();
	public static final CellTemplate CLOSED_DOOR = initCLOSED_DOOR();
	
	private static final CellTemplate initAIR() {
		CellTemplate template = new CellTemplate(' ', (int)' ');
		template.walkable = true;
		template.solid = false;
		template.liquid = false;
		cells.put(template.TEMPLATE_ID, template);
		return template;
	}
	
	private static final CellTemplate initGRANITE_WALL() {
		CellTemplate template = new CellTemplate('#', (int)'#');
		template.walkable = false;
		template.solid = true;
		template.liquid = false;
		cells.put(template.TEMPLATE_ID, template);
		return template;
	}

	private static final CellTemplate initSTAIRS_UP() {
		CellTemplate template = new CellTemplate('<', (int)'<');
		template.walkable = true;
		template.solid = false;
		template.liquid = false;
		cells.put(template.TEMPLATE_ID, template);
		return template;
	}
	
	private static final CellTemplate initSTAIRS_DOWN() {
		CellTemplate template = new CellTemplate('>', (int)'>');
		template.walkable = true;
		template.solid = false;
		template.liquid = false;
		cells.put(template.TEMPLATE_ID, template);
		return template;
	}
	
	private static final CellTemplate initOPEN_DOOR() {
		CellTemplate template = new DoorTemplate(',', (int)',');
		cells.put(template.TEMPLATE_ID, template);
		return template;
	}
	
	private static final CellTemplate initCLOSED_DOOR() {
		CellTemplate template = new CellTemplate('+', (int)'+');
		cells.put(template.TEMPLATE_ID, template);
		return template;
	}
	
	public static CellTemplate getTemplate(int TEMPLATE_ID)
	{
		return cells.get(TEMPLATE_ID);	
	}
	
	public boolean contains(int TEMPLATE_ID) {
		if(cells.containsKey(TEMPLATE_ID))
			return true;
		return false;
	}
}
