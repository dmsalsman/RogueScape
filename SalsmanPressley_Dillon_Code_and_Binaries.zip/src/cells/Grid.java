package cells;

import java.io.File;
import java.util.Scanner;

public class Grid
{
	public int SIZE = 64;
	
	public Cell[][] cells;
	
	Grid() {
		cells = new Cell[SIZE][SIZE];
	}
	
	Grid(int size) {
		this.SIZE = size;
		cells = new Cell[SIZE][SIZE];
	}
	
	public static void clearCells(Grid grid) {
		for(int i=0;i<grid.SIZE;i++)
			for(int j=0;j<grid.SIZE;j++)
				grid.cells[i][j] = Cells.AIR.makeInstance();
	}
	
	public static void fillCells(Grid grid, CellTemplate cellType)
	{
		for(int i=0;i<grid.SIZE;i++)
			for(int j=0;j<grid.SIZE;j++)
				grid.cells[i][j] = cellType.makeInstance();
	}
	
	public static Grid getGridFromFile(String url)
	{
		return getGridFromFile(new File(url));
	}
	
	public static Grid getGridFromFile(File file) {
		Grid grid = new Grid();
		try {
			Scanner in = new Scanner(file);
			grid.SIZE = in.nextInt();
			for(Cell[] row: grid.cells)
				for(Cell cell: row)
					cell = Cells.getTemplate(in.nextInt());
		} catch(Exception e) {
			System.err.println(e.getMessage());
			return null;
		}
		return grid;
	}
}
