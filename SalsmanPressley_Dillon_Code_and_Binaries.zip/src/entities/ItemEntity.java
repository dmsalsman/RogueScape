package entities;

import misc.Representation;

public class ItemEntity extends Entity
{
	private Representation representation;
	
	public char getRepresentation() {
		return representation.ASCII;
	}
}
