package entities;
import misc.Representable;
import misc.Representation;


public abstract class Entity implements Representable
{
	protected Representation DEFAULT_REPRESENTATION;
	String name;
	String description;
	
	@Override
	public char getRepresentation()
	{
		return DEFAULT_REPRESENTATION.ASCII;
	}
	
	public char getDefaultRepresentation() {
		return DEFAULT_REPRESENTATION.ASCII;
	}
	
	public void setRepresentation(char ASCII)
	{
		this.DEFAULT_REPRESENTATION.setASCII(ASCII);
	}
}
