package entities;

public class LivingEntity extends Entity
{
	Inventory inventory = new Inventory();
	public int x, y;
}
