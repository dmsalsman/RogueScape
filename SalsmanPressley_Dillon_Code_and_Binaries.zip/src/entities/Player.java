package entities;

import misc.Representation;


public class Player extends LivingEntity
{
	public Player() {
		DEFAULT_REPRESENTATION = new Representation('@');
	}
}
