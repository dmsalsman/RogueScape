import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

import misc.Util;
import cells.Cell;
import cells.Dungeon;
import entities.Player;


public class Game extends JPanel
{
	private static final int VIEW_DISTANCE = 8;
	private static final long	serialVersionUID	= -824413027067294540L;
	
	//Uses Singleton design pattern
	private static  Game instance = getInstance();
	
	Dungeon d = new Dungeon();
	Player p = new Player();
	Game() {
		init();
	}
	
	//Uses Singleton design pattern
	public static Game getInstance() {
		if(instance != null)
			return instance;
		instance = new Game();
		return instance;
	}
	
	private void init() {
		//init Game variables
		d = new Dungeon();
		p.x = d.getStartX();
		p.y = d.getStartY();
		d.cells[p.x][p.y].setLivingEntity(p);
		
		//init GUI stuff
		JFrame container = new JFrame("RogueScape");
		container.addKeyListener(new GameKeyHandler());
		container.setContentPane(this);
		container.setSize(640, 480);	
		container.setVisible(true);
	}
	
	public static void movePlayer(int direction) {
		//uses helper functions in Util class to determin new location
		int x = instance.p.x + Util.getDX(direction);
		int y = instance.p.y + Util.getDY(direction);
		//checks if cell is in array bounds
		// 		 if cell is walkable
		//		 and if cell isn't already occupied
		if(Util.isValidLocation(x, y, instance.d.SIZE) && instance.d.cells[x][y].isWalkable() && instance.d.cells[x][y].setLivingEntity(instance.p)) {
			instance.d.cells[instance.p.x][instance.p.y].clearLivingEntity();
			instance.p.x = x;
			instance.p.y = y;
		}
		instance.repaint();
	}
	
	//duh.. gets dat der cell dat has duh p'ayer init
	public Cell getCellContainingPlayer() {
		return d.cells[p.x][p.y];
	}
	
	//Prints from VIEW_DISTANCE cells north-west of the player to 
	//VIEW_DISTANCE cells south-east, accounting for array bounds
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Font backup = g.getFont();
		g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 24));
		int x = p.x - VIEW_DISTANCE;
		int y = p.y - VIEW_DISTANCE;
		for(int i=1; i<(VIEW_DISTANCE*2 + 2); i++)
			for(int j=1; j<(VIEW_DISTANCE*2 + 2); j++)
			{
				if((x+i) < 0 || (y+j) < 0 || (x+i) >= d.SIZE || (y+j) >= d.SIZE)
					g.drawString("~", i*24, j*24);
				else
					g.drawString(""+d.cells[x+i][y+j].getRepresentation(), i*24, j*24);
			}
		g.setFont(backup);
		this.repaint();
	}
	
	//Handles all keyboard input
	private class GameKeyHandler extends KeyAdapter {
		public GameKeyHandler()
		{
			super();
			// TODO Auto-generated constructor stub
		}
		@Override
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_H)
				Game.movePlayer(Util.WEST);
			else if(e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_L)
				Game.movePlayer(Util.EAST);
			else if(e.getKeyCode() == KeyEvent.VK_DOWN ||  e.getKeyCode() == KeyEvent.VK_J)
				Game.movePlayer(Util.SOUTH);
			else if(e.getKeyCode() == KeyEvent.VK_UP  || e.getKeyCode() == KeyEvent.VK_K)
				Game.movePlayer(Util.NORTH);
			else if(e.getKeyCode() == KeyEvent.VK_PERIOD)
				Game.descendFloor();
			else if(e.getKeyCode() == KeyEvent.VK_COMMA)
				Game.ascendFloor();
			
		}
	}
	
	public static void main(String[] args) {
		Game instance = Game.instance;
	}

	public static void descendFloor()
	{
		if(instance.getCellContainingPlayer().getDefaultRepresentation() == '>')
		{
			instance.d = new Dungeon();
			instance.p.x = instance.d.getStartX();
			instance.p.y = instance.d.getStartY();
			instance.getCellContainingPlayer().setLivingEntity(instance.p);
			instance.repaint();
		}
	}

	public static void ascendFloor()
	{
		if(instance.getCellContainingPlayer().getDefaultRepresentation() == '<')
		{
			instance.d = new Dungeon();
			instance.p.x = instance.d.getEndX();
			instance.p.y = instance.d.getEndY();
			instance.getCellContainingPlayer().setLivingEntity(instance.p);
			instance.repaint();
		}
	}
}
